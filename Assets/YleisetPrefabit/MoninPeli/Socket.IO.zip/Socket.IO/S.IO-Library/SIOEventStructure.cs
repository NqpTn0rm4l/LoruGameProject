﻿namespace Firesplash.UnityAssets.SocketIO
{
    internal struct SIOEventStructure {
        public string eventName;
        public string data;
    }
}
